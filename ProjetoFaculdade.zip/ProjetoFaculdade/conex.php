<?php

	define('HOST','localhost');
	define('USER','root');
	define('PASS','khalifa1');  
	define('DB','mangekyou');
	
	$con = mysqli_connect(HOST,USER,PASS,DB); 

	if (!$con ) {
         echo "Erro na Conexão";
    } else {
         echo "Conectado!";
    }
?>
	
	