<?php 
  
  $variavel_email = $_POST['email']; 
  $variavel_senha = $_POST['senha'];
  
  require_once('conex.php'); 
  
  if(!$con) 
  {
	echo 'Erro de Conexão !'; 
  }
  
  if(!mysqli_select_db($con,'mangekyou')) 
  {
	echo 'Banco não Encontrado !';
  }
  
  $sql= "SELECT * FROM sharingan WHERE email = '$variavel_email' && senha = '$variavel_senha'"; 
  
  $resultado = mysqli_query($con,$sql);
  $positivos = mysqli_num_rows($resultado);


if($positivos > 0 )
{
	echo 'LOGOU';
}

else
{
	echo 'ERRO AO LOGAR!';
}	

?>