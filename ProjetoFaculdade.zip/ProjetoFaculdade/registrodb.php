<?php 

   $con = mysqli_connect("127.0.0.1","root","dbtrabalho");	
 
   if(!$con){
	echo 'Erro de Conexão!'; }

   if(!mysqli_select_db($con,'mangekyou')){
	echo 'Banco não Encontrado!';}
	
 	$nome = $_POST['nom'];      
	$senha = $_POST['sen']; 
 	$data_nas = $_POST['dat'];    
 	$genero= $_POST['gen'];
 	$email = $_POST['ema'];     
 	$numero_tel = $_POST['numt'];
 	$assunto = $_POST['assu'];    
 
    $sql = "INSERT INTO sharingan (nome,senha,data_nascimento,genero,email,numero_telefone,assunto) VALUES('$nome','$senha','$data_nas','$genero','$email','$numero_tel','$assunto')";                        					 
	
    if(!mysqli_query($con,$sql)){ 
		echo 'Erro ao cadastrar!';
	}
	else {
		echo 'Cadastrado com sucesso';
	}
     exit;
?>
   
  

 
	 
    
