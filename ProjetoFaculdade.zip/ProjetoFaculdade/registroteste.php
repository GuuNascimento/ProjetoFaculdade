<?php 

   $con = mysqli_connect("127.0.0.1","root","khalifa1");	
 
   if(!$con){
	echo 'Erro de Conexão!'; }

   if(!mysqli_select_db($con,'mangekyou')){
	echo 'Banco não Encontrado!';}
	
 	$nome = "a";      
	$senha = "b"; 
 	$data_nas = "c";    
 	$genero= "d";
 	$email = "e";     
 	$numero_tel = "f";
 	$assunto = "g";    
 
    $sql = "INSERT INTO sharingan (nome,senha,data_nascimento,genero,email,numero_telefone,assunto) VALUES('$nome','$senha','$data_nas','$genero','$email','$numero_tel','$assunto')";                         					 
	
    if(!mysqli_query($con,$sql)){ 
		echo 'O banco não foi encontrado!';
	}
	else {
		echo 'Cadastrado com sucesso';
	}
     exit;
?>
   
  

 
	 
    
